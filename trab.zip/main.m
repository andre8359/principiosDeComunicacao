clear all; close  all; clc;

fs =4e5;
f_portadora = 2e4;


t = 0 :1/fs:5;
sinal = wavread('music.wav');
sinal=sinal(:).';
sinal_modulado=modulacao_AM_DSB_SC(sinal,fs,f_portadora);
[sinal_demodulado delay]=demodulacao_AM_DSB_SC(sinal_modulado,fs,f_portadora);

L = min([length(sinal) length(sinal_demodulado)]);
sinal_demodulado=sinal_demodulado-mean(sinal_demodulado);
sinal_demodulado=sinal_demodulado/max(sinal_demodulado);
sinal_demodulado(find(sinal_demodulado < -1)) = -1;
sinal_demodulado(find(sinal_demodulado > +1)) = +1;
	
sinal_demodulado = sinal_demodulado(1+delay:L);
sinal = sinal/max(abs(sinal));
sinal=sinal(1:L-delay);


figure;
plot(sinal_demodulado+sinal);
hold on;grid on;

musica = downsample(sinal_demodulado,fs/8e3);
audiowrite('nome.wav',musica,8000);